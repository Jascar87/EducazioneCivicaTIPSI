﻿using System;

namespace EsercizioGITv0._1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Inserisci una stringa: ");
            string s = Console.ReadLine();
            Console.Write("Inserisci un numero: ");
            int n = int.Parse(Console.ReadLine());

            char[] arr = s.ToCharArray();

            for (int i = 0; i < arr.Length; i++)
            {
                if (char.IsLetter(arr[i]))
                {
                    char c = (char)(arr[i] + n);
                    if (c > 'z')
                        c = (char)(c - 26);
                    arr[i] = c;
                }
            }

            string result = new string(arr);
            Console.WriteLine(result);
        }
    }
}
